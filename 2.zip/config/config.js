var config = {
    host: '39.107.65.116',
    port: 3306,
    database: 'lsb',
    user: 'lsb',
    password: 'lsb666'
}
module.exports = config