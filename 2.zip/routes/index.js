const router = require('koa-router')()
const { user } = require('../config/config')
const sql = require('../mysql')
    /*router.get('/', async(ctx, next) => {
        await ctx.render('index', {
            title: '蒋毛小可爱'
        })
    })*/
router.get('/', async(ctx, next) => {
    await ctx.render('index', {
        title: '智能充电桩API站点'
    })
})
router.get('/order', async(ctx, next) => {
    const res = await sql.query('SELECT * from orders')
    ctx.body = res
})
router.post('/order', async(ctx, next) => {
    param = ctx.request.body
    method = param.method

    var timestamp = Date.parse(new Date()) / 1000;
    if (method == "start") {
        user_id = param.user_id;
        device_id = param.device_id;
        my_id = param.my_id;
        console.log(user_id, device_id, my_id)
        if (user_id == null || device_id == null || my_id == null) {
            ctx.body = {
                status: false,
                message: 'please set user_id and device_id and my_id'
            }
        } else {
            const res = await sql.query("INSERT INTO `orders` (`user_id`, `device_id`, `my_id`, `time_start`,`time_end`) VALUES ('" + user_id + "', '" + device_id + "', '" + my_id + "', '" + timestamp + "', '" + 0 + "')")
            ctx.body = {
                status: true,
                user_id: user_id,
                device_id: device_id,
                my_id: my_id,
                timestamp: timestamp,
                message: 'success to insert mysql'
            }
        }
    } else if (method == "end") {
        my_id = param.my_id
        if (my_id == null) {
            ctx.body = {
                stauts: false,
                message: 'please input my id to find what are you want to end at the database'
            }
        } else {

            const res = await sql.query("UPDATE `orders` SET `time_end`= '" + timestamp + "' WHERE my_id=" + my_id)
            ctx.body = {
                status: true,
                message: 'request is already submit,but it success depend input my_id which you input justnow'
            }
        }
    } else {
        ctx.body = {
            status: false,
            message: 'please set method get or post'
        }
    }
    date = new Date()
        //time = `${date.getFullYear()}-${date.getMonth()<9?'0'+(date.getMonth()+1):date.getMonth()+1}-${date.getDate()<10?'0'+date.getDate():date.getDate()} ${date.getHours()<10?'0'+date.getHours():date.getHours()}:${date.getMinutes()<10?'0'+date.getMinutes():date.getMinutes()}:${date.getSeconds()<10?'0'+date.getSeconds():date.getSeconds()}`
})
router.get('/find', async(ctx, next) => {
    const res = await sql.query('SELECT * from areas')
    ctx.body = res
})
router.post('/question', async(ctx, next) => {
    param = ctx.request.body
    content = param.content
    submit_time = Date.parse(new Date()) / 1000; // 当前时间戳，精确到秒
    user_name = param.user_name;
    user_id = param.user_id;
    phone = param.phone;
    if (content == null || user_name == null || user_id == null || phone == null) {
        ctx.body = {
            stauts: false,
            message: '参数不全'
        }
    } else {
        const res = await sql.query("INSERT INTO `questions` (`content`, `submit_time`, `user_name`, `user_id`,`phone`) VALUES ('" + content + "', '" + submit_time + "', '" + user_name + "', '" + user_id + "', '" + phone + "')")
        ctx.body = {
            stauts: true,
            message: '已成功提交'
        }
    }

})
router.get('/question', async(ctx, next) => {
    const res = await sql.query('SELECT * from questions')
    ctx.body = {
        title: '>>>'
    }
})
router.get('/json', async(ctx, next) => {

    ctx.body = {
        title: 'koa2 json'
    }
})
module.exports = router